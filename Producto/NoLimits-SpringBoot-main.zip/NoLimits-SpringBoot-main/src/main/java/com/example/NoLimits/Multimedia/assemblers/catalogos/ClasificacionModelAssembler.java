package com.example.NoLimits.Multimedia.assemblers.catalogos;

import com.example.NoLimits.Multimedia.controllerV2.catalogos.ClasificacionControllerV2;
import com.example.NoLimits.Multimedia.dto.catalogos.response.ClasificacionResponseDTO;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

/**
 * Assembler encargado de transformar un objeto ClasificacionResponseDTO
 * en una representación HATEOAS enriquecida con enlaces dinámicos.
 *
 * Implementa RepresentationModelAssembler para incluir links que
 * guían al cliente a través de las posibles acciones disponibles,
 * siguiendo el principio HATEOAS (Hypermedia As The Engine Of Application State).
 */
@Component
public class ClasificacionModelAssembler implements RepresentationModelAssembler<ClasificacionResponseDTO, EntityModel<ClasificacionResponseDTO>> {

    /**
     * Convierte un objeto ClasificacionResponseDTO en un EntityModel con enlaces HATEOAS.
     *
     * @param clasificacion DTO de clasificación base
     * @return EntityModel con enlaces auto-descriptivos
     */
    @Override
    public EntityModel<ClasificacionResponseDTO> toModel(ClasificacionResponseDTO clasificacion) {

        // Se crea la representación base con el DTO + links principales
        EntityModel<ClasificacionResponseDTO> model = EntityModel.of(
                clasificacion,

                // ================================
                // 🔹 ENLACE SELF (Recurso actual)
                // ================================
                linkTo(methodOn(ClasificacionControllerV2.class)
                        .getById(clasificacion.getId()))
                        .withSelfRel(),

                // ================================
                // 🔹 OPERACIONES CRUD
                // ================================

                // Actualización completa (PUT)
                linkTo(methodOn(ClasificacionControllerV2.class)
                        .update(clasificacion.getId(), null))
                        .withRel("actualizar"),

                // Actualización parcial (PATCH)
                linkTo(methodOn(ClasificacionControllerV2.class)
                        .patch(clasificacion.getId(), null))
                        .withRel("actualizar_parcial"),

                // Eliminación
                linkTo(methodOn(ClasificacionControllerV2.class)
                        .delete(clasificacion.getId()))
                        .withRel("eliminar"),

                // ================================
                // 🔹 COLECCIÓN DE RECURSOS
                // ================================

                // Listado general de clasificaciones
                linkTo(methodOn(ClasificacionControllerV2.class)
                        .getAll())
                        .withRel("clasificaciones"),

                // Crear nueva clasificación
                linkTo(methodOn(ClasificacionControllerV2.class)
                        .create(null))
                        .withRel("crear"),

                // Alias de listado completo
                linkTo(methodOn(ClasificacionControllerV2.class)
                        .getAll())
                        .withRel("listar_todas"),

                // Alias alternativo para la colección
                linkTo(methodOn(ClasificacionControllerV2.class)
                        .getAll())
                        .withRel("self_collection")
        );

        // =====================================================
        // 🔹 Enlaces condicionales según contenido del modelo
        // =====================================================

        // Si la clasificación tiene nombre, se añade un link relacionado
        if (clasificacion.getNombre() != null && !clasificacion.getNombre().isBlank()) {
            model.add(
                    linkTo(methodOn(ClasificacionControllerV2.class)
                            .getAll())
                            .withRel("relacionada_por_nombre")
            );
        }

        return model;
    }
}